import React from "react";

// Footer Component
const Footer = ({ id }) => {
  return (
    <footer id={id} className="p-4 bg-red-700 text-white text-center h-[40vh]">
      <p className="text-sm">Footer Content © 2025</p>
    </footer>
  );
};

export default Footer;
