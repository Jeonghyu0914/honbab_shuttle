import React from "react";
import smoothScroll from "../utils/smoothScroll.js"; // 스크롤 함수 분리

// Header Component
const Header = ({ isTransparent }) => {
  return (
    <header className={`sticky top-0 z-50 p-4 transition-all duration-300 ${isTransparent ? "bg-transparent" : "bg-red-700 text-white"} flex justify-between items-center w-full`}>
      <h1 className="text-2xl font-bold">혼밥셔틀</h1>
      <nav className="flex justify-center items-center absolute inset-0">
        <ul className="flex space-x-4">
          <li>
            <a href="#main1" onClick={(e) => smoothScroll(e, "main1")} className="hover:underline">
              브랜드
            </a>
          </li>
          <li>
            <a href="#categoryNav" onClick={(e) => smoothScroll(e, "CategoryNav")} className="hover:underline">
              메뉴
            </a>
          </li>
          <li>
            <a href="#business" onClick={(e) => smoothScroll(e, "business")} className="hover:underline">
              창업
            </a>
          </li>
        </ul>
      </nav>
      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex space-x-4">
        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
          <img src="https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/instagram-white-icon.png" alt="Instagram" className="w-6 h-6" />
        </a>
        <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
          <img src="https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/youtube-app-white-icon.png" alt="YouTube" className="w-6 h-6" />
        </a>
      </div>
    </header>
  );
};

export default Header;
