import React, { useEffect, useState, useRef } from "react";

const MainPage = ({ id, image }) => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting); // 화면에 보이면 true, 사라지면 false
      },
      { threshold: 0.3 } // 30% 이상 보이면 트리거
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  return (
    <section id={id} ref={sectionRef} className="w-full flex items-center justify-center bg-black">
      <img
        src={image}
        alt="메인 이미지"
        className={`w-full h-auto object-cover transition-all duration-1000 ease-out 
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
      />
    </section>
  );
};

export default MainPage;
