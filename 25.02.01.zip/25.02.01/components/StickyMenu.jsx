import React, { useEffect, useState } from "react";

const StickyMenu = () => {
  return (
    <div className="z-100 fixed bottom-0 left-0 w-full bg-red-700 p-4 shadow-lg transition-all duration-300 flex justify-center">
      <div className="flex flex-wrap justify-center items-center max-w-screen-lg w-full gap-3">
        {/* 입력 필드 그룹 */}
        <div className="flex flex-nowrap gap-2 w-full">
          <input type="text" placeholder="성함" className="flex-1 min-w-0 p-2 border border-gray-300 rounded bg-white text-gray-700 max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg" />
          <input type="text" placeholder="지역" className="flex-1 min-w-0 p-2 border border-gray-300 rounded bg-white text-gray-700 max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg" />
          <input type="text" placeholder="연락처" className="flex-1 min-w-0 p-2 border border-gray-300 rounded bg-white text-gray-700 max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg" />
        </div>

        {/* 체크박스 및 버튼 */}
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center space-x-2 text-white">
            <input type="checkbox" className="w-5 h-5" />
            <span>개인정보 수집 및 이용에 동의</span>
          </label>
          <button className="bg-white text-red-600 font-semibold py-2 px-6 rounded-lg shadow hover:bg-gray-200 transition">문의하기</button>
        </div>
      </div>
    </div>
  );
};

export default StickyMenu;
